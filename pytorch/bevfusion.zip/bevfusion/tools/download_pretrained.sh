mkdir pretrained &&
cd pretrained &&
wget https://bevfusion.mit.edu/files/pretrained_updated/bevfusion-det.pth &&
wget https://bevfusion.mit.edu/files/pretrained_updated/bevfusion-seg.pth &&
wget https://bevfusion.mit.edu/files/pretrained/lidar-only-det.pth &&
wget https://bevfusion.mit.edu/files/pretrained/lidar-only-seg.pth &&
wget https://bevfusion.mit.edu/files/pretrained_updated/camera-only-det.pth &&
wget https://bevfusion.mit.edu/files/pretrained_updated/camera-only-seg.pth &&
wget https://bevfusion.mit.edu/files/pretrained_updated/swint-nuimages-pretrained.pth

