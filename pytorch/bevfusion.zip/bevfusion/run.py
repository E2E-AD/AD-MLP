import random
import os
rid=random.randint(100,350000)
os.system('sh run.sh {}'.format(rid))
