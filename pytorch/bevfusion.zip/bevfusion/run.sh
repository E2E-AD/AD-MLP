sh k2.sh
torchpack dist-run -H localhost:$1 -np 8 python tools/train.py configs/nuscenes/det/transfusion/secfpn/camera+lidar/swint_v0p075/lidar_only.yaml --load_from pretrained/lidar-only-det.pth 
python losscurve.py
python merge_val.py