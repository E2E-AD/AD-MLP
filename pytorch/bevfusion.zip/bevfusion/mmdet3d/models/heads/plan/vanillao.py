from typing import Any, Dict, List, Optional, Tuple, Union

import torch
from torch import nn
from torch.nn import functional as F
import pickle
from mmdet3d.models.builder import HEADS
from mmdet3d.models.utils import FFN, PositionEmbeddingLearned, TransformerDecoderLayer
import numpy as np
import math
from torchmetrics import Metric
import copy
from skimage.draw import polygon
__all__ = ["VanillaPlanHead","VanillaPlanHead2"]

def gen_dx_bx(xbound, ybound, zbound):
    dx = torch.Tensor([row[2] for row in [xbound, ybound, zbound]])
    bx = torch.Tensor([row[0] + row[2]/2.0 for row in [xbound, ybound, zbound]])
    nx = torch.LongTensor([(row[1] - row[0]) / row[2] for row in [xbound, ybound, zbound]])

    return dx, bx, nx


def calculate_birds_eye_view_parameters(x_bounds, y_bounds, z_bounds):
    """
    Parameters
    ----------
        x_bounds: Forward direction in the ego-car.
        y_bounds: Sides
        z_bounds: Height

    Returns
    -------
        bev_resolution: Bird's-eye view bev_resolution
        bev_start_position Bird's-eye view first element
        bev_dimension Bird's-eye view tensor spatial dimension
    """
    bev_resolution = torch.tensor([row[2] for row in [x_bounds, y_bounds, z_bounds]])
    bev_start_position = torch.tensor([row[0] + row[2] / 2.0 for row in [x_bounds, y_bounds, z_bounds]])
    bev_dimension = torch.tensor([(row[1] - row[0]) / row[2] for row in [x_bounds, y_bounds, z_bounds]],
                                 dtype=torch.long)

    return bev_resolution, bev_start_position, bev_dimension

def l2_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    reduction: str = "mean",
) -> torch.Tensor:
    inputs = inputs.float()
    targets = targets.float()
    valid = targets > (-5e3)
    return F.mse_loss(inputs[valid], targets[valid], reduction=reduction)

def l1_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    reduction: str = "mean",
) -> torch.Tensor:
    inputs = inputs.float()
    targets = targets.float()
    valid = targets > (-5e3)
    return F.l1_loss(inputs[valid], targets[valid], reduction=reduction)

@HEADS.register_module()
class VanillaPlanHead(nn.Module):
    def __init__(
        self,
        num_heads=8,
        hidden_dim=256,
        dropout=0.1,
        activation='relu',
        ffn_channels=256,
        future_frames=6
    ):
        super().__init__()

        self.future_frames = future_frames

        self.decoder = nn.ModuleList()
        self.decoder.append(
            TransformerDecoderLayer(
                hidden_dim,
                num_heads,
                ffn_channels,
                dropout,
                activation,
                # self_posembed=PositionEmbeddingLearned(2, hidden_dim),
                # cross_posembed=PositionEmbeddingLearned(2, hidden_dim),
            )
        )

        self.plan_head = nn.ModuleList()
        self.plan_head.append(
            FFN(
                hidden_dim,
                heads={"x{}".format(i):[3,2] for i in range(1,8)},
                conv_cfg=dict(type="Conv1d"),
                norm_cfg=dict(type="BN1d"),
                bias="auto",
            )
        )

        self.ego_query = nn.Embedding(1,hidden_dim)
    
    def forward(self, input, **kwargs):
        if isinstance(input,list):
            input=input[0]
        # print(input.shape)
        # print(type(input),len(input),input[0].shape)
        # exit(0)
        B, C, _, _ = input.shape



        input = input.view(
            B, C, -1 
        ) # [BS, C, H*W]

        query_feat = self.decoder[0](
            self.ego_query.weight.unsqueeze(0).repeat(B, 1, 1).permute(0,2,1), input, query_pos=None, key_pos=None,
        )

        # print(query_feat.shape) # bs,512,1
        
        # prior injection
        if 'answer' in kwargs:
            pass
            # gt_trag = kwargs['answer']
            # per_offset = []
            # for i in range(gt_trag.shape[1]-1):
            #     per_offset.append(gt_trag[:,i+1]-gt_trag[:,i])
            # per_offset = torch.stack(per_offset,dim=-1).mean(dim=-1)
            # query_feat[:,:per_offset.shape[1]]+=per_offset.unsqueeze(-1) / 108.0
            # print(gt_trag.shape) # bs,7,3
            # gt_trag = gt_trag.flatten(1).unsqueeze(-1) # bs,21,1

            # sz = gt_trag.shape[1]
            # query_feat[:,:sz]+=gt_trag
        

        waypoints = self.plan_head[0](query_feat)

        
        # if 'token' in kwargs:
        #     if not hasattr(self,'past'):
        #         with open('train_past.pkl','rb')as f:
        #             self.past=pickle.load(f)
            
        #     tokens=kwargs['token']
        #     for j,token in enumerate(tokens):
        #         last_tj=[0,0,0]
        #         if token in self.past:
        #             o=self.past[token]['gt_trajectory'][0]
        #             if not(o is None):
        #                 last_tj=o
        #         last_tj=torch.tensor(last_tj).unsqueeze(-1)
        #         for i in range(1,8):
        #             name='x{}'.format(i)
        #             # print(waypoints[name].shape,last_tj.shape)
        #             # exit(0)
        #             waypoints[name][j] = torch.zeros_like(waypoints[name][j])
        #             waypoints[name][j] = waypoints[name][j] - (i-1) * last_tj.to(waypoints[name].device)
            
        

        # for k in waypoints:
        #     waypoints[k][:,:2] = torch.sigmoid(waypoints[k][:,:2]) * 1 - 0.5 

        # initial_velocity = waypoints['x1'] # bs,3,1
        # for i in range(2,8):
        #     waypoints['x{}'.format(i)] = waypoints['x{}'.format(i)] + (i-1) * initial_velocity


        return waypoints
    
    def loss(self, predict_dict, gt_trajectory):
        # print(gt_trajectory.shape) # bs,7,3
        gt_trajectory = gt_trajectory.permute(1,2,0)
        loss_dict={}
        
        predict = torch.cat((predict_dict['x1'],predict_dict['x2'],predict_dict['x3'],predict_dict['x4'],predict_dict['x5'],predict_dict['x6'],predict_dict['x7']),dim = -1)
        predict=predict.permute(2,1,0)
        # print(predict.shape) #7,3,bs
        # print(predict,'ww')
        # print(gt_trajectory,'uu')
        # exit(0)
        # for i in range(1,7):
        #     predict[i] = predict[i] + (gt_trajectory[1] - gt_trajectory[0]) * i
        # print(predict[:,:,0],gt_trajectory[:,:,0])
        loss = l1_loss(predict, gt_trajectory)
            
        loss_dict = {'default_loss': loss/1}
        return loss_dict

class PlanningMetric_3:
    def __init__(
        self,
        n_future=6,
    ):
        X_BOUND = [-54.0, 54.0, 0.6]  # Forward
        Y_BOUND = [-54.0, 54.0, 0.6]  # Sides
        Z_BOUND = [-10.0, 10.0, 20.0]
        dx, bx, _ = gen_dx_bx(X_BOUND, Y_BOUND, Z_BOUND)
        dx, bx = dx[:2], bx[:2]
        self.dx = nn.Parameter(dx, requires_grad=False)
        self.bx = nn.Parameter(bx, requires_grad=False)

        _, _, self.bev_dimension = calculate_birds_eye_view_parameters(X_BOUND, Y_BOUND, Z_BOUND)
        self.bev_dimension = self.bev_dimension.numpy()
        WIDTH = 1.85
        HEIGHT = 4.084
        self.W = WIDTH
        self.H = HEIGHT

        self.n_future = n_future


    def evaluate_single_coll(self, traj, segmentation):
        '''
        gt_segmentation
        traj: torch.Tensor (n_future, 2)
        segmentation: torch.Tensor (n_future, 200, 200) -> (n_future, x, 2)
        '''
        n_future, _ = traj.shape
        n_future = min(len(segmentation), n_future)
        traj=traj.clone()
        traj = traj * torch.tensor([-1, 1], device=traj.device)
        occidxs=copy.deepcopy(segmentation)
        pts = np.array([
            [-self.H / 2. + 0.5, self.W / 2.],
            [self.H / 2. + 0.5, self.W / 2.],
            [self.H / 2. + 0.5, -self.W / 2.],
            [-self.H / 2. + 0.5, -self.W / 2.],
        ])
        pts = (pts - self.bx.cpu().numpy()) / (self.dx.cpu().numpy())
        pts[:, [0, 1]] = pts[:, [1, 0]]
        
        rr, cc = polygon(pts[:,1], pts[:,0])
        rc = np.concatenate([rr[:,None], cc[:,None]], axis=-1)

        trajs = traj.view(traj.shape[0], 1, 2)
        trajs[:,:,[0,1]] = trajs[:,:,[1,0]] # can also change original tensor
        trajs = trajs / self.dx.to(trajs.device)
        rc=torch.tensor(rc).to(trajs.device).to(trajs.dtype)
        trajs = trajs + rc # (n_future, 32, 2)
        
        # trajs is converted to pixel index
        r = trajs[:,:,0].to(torch.int32)
        r = torch.clip(r, 0, self.bev_dimension[0] - 1)

        c = trajs[:,:,1].to(torch.int32)
        c = torch.clip(c, 0, self.bev_dimension[1] - 1)

        distance=[]
        for t in range(n_future):
            rr = r[t]
            cc = c[t]
            I = (rr>=0)&(cc>=0)&(rr<self.bev_dimension[0])&(cc<self.bev_dimension[1])
            rr=rr[I].to(torch.float32)
            cc=cc[I].to(torch.float32)
            rr=rr.mean(dim=0)
            cc=cc.mean(dim=0)
            cur_occ=torch.tensor(occidxs[t]).to(rr.dtype).to(rr.device)
            # min distance to collide
            cur_occ[:,0] = cur_occ[:,0] - rr
            cur_occ[:,1] = cur_occ[:,1] - cc
            cur_occ = (cur_occ * cur_occ).sum(dim=-1)
            values, indices = torch.topk(cur_occ, min(3,len(cur_occ)), largest=False)
            distance.append(values.mean())
        return sum(distance)/n_future

        

 



@HEADS.register_module()
class VanillaPlanHead2(nn.Module):
    def __init__(
        self,
        num_heads=8,
        hidden_dim=256,
        dropout=0.1,
        activation='relu',
        ffn_channels=256,
        future_frames=6
    ):
        super().__init__()
        self.velocity_dim=3
        self.past_frame=5
        self.plan_head=nn.Sequential(
							nn.Linear(hidden_dim+self.velocity_dim*(self.past_frame+1), 512),
							nn.ReLU(inplace=True),
                            nn.Linear(512, 512),
                            nn.Dropout(p=0.1),
                            nn.ReLU(inplace=True),
                            nn.Linear(512,7*3)
						)
        self.occ_metric=PlanningMetric_3()
    def forward(self, input, **kwargs):
        if isinstance(input,list):
            input=input[0]
        
        B, C, _, _ = input.shape

        input = F.adaptive_avg_pool2d(input, 1).squeeze(-1).squeeze(-1)
        
        if 'token' in kwargs:
            if not hasattr(self,'past'):
                with open('train_past.pkl','rb')as f:
                    self.past=pickle.load(f)
                with open('val_past.pkl','rb')as f:
                    a=pickle.load(f)
                    for k in a:
                        self.past[k]=a[k]
            if not hasattr(self,'all_past'):
                with open('all_prevs.pkl','rb')as f:
                    self.all_past=pickle.load(f)
            if not hasattr(self,'all_next'):
                with open('all_next.pkl','rb')as f:
                    self.all_next=pickle.load(f)
                
            # if not hasattr(self,'occ'):
            #     self.occ=pickle.load(open('occidx.pkl','rb'))

                
            
            tokens=kwargs['token']
            velocitys=[]

            for j,token in enumerate(tokens):
                assert token in self.all_past
                past_tr=self.all_past[token]
                if len(past_tr)>self.past_frame:
                    past_tr=past_tr[:self.past_frame]
                while len(past_tr)<self.past_frame:
                    past_tr.append([0,0,0])
                past_tr.append(self.all_next[token][1] if token in self.all_next and len(self.all_next[token])>1 else [0,0,0])
                past_tr=torch.tensor(past_tr).to(input.device).to(input.dtype).flatten().unsqueeze(-1)
                velocitys.append(past_tr)


        velocitys=torch.cat(velocitys,dim=-1).permute(1,0)
        
        input=torch.cat([input,velocitys],dim=-1)
        
                
        input=self.plan_head(input)

        waypoints = {}
        for i in range(1,8):
            waypoints['x{}'.format(i)]=input[:,3*(i-1):3*i].unsqueeze(-1)
        return waypoints
    
    def loss(self, predict_dict, gt_trajectory,**kwargs):
        # print(gt_trajectory.shape) # bs,7,3
        gt_trajectory = gt_trajectory.permute(1,2,0) # 7,3,bs
        loss_dict={}
        
        predict = torch.cat((predict_dict['x1'],predict_dict['x2'],predict_dict['x3'],predict_dict['x4'],predict_dict['x5'],predict_dict['x6'],predict_dict['x7']),dim = -1)
        predict=predict.permute(2,1,0)
        loss = l1_loss(predict, gt_trajectory)
        loss_dict = {'default_loss': loss}
        # loss_occ = torch.zeros((1), requires_grad=True).to(predict.device).mean()

        # if 'token' in kwargs:
        #     tokens=kwargs['token']
        #     predict_bs=predict.permute(2,0,1) # bs,7,3
        #     for token,pred in zip(tokens,predict_bs):
        #         if token in self.occ:
        #             occ_idxs=self.occ[token]
        #             loss_occ = loss_occ + self.occ_metric.evaluate_single_coll(pred[1:,:2],occ_idxs)
        #             # for i in range(n_future):
        #             #     cpred=pred[i+1][:2] # x,y
        #             #     cocc=torch.tensor(occ_idxs[i]).to(float).to(predict.device)

        #             #     if len(cocc):
        #             #         cocc=(cocc-90)/180*108
        #             #         cocc=cocc-cpred
        #             #         cocc=torch.sqrt((cocc*cocc).sum(dim=-1)+1e-5)
        #             #         if cocc.min()<5:
        #             #             occ_cnt+=1
        #             #             loss_occ = loss_occ + cocc.min()

        # if abs(loss_occ)>100:
        #     loss_occ = torch.zeros((1), requires_grad=True).to(predict.device).mean()
        
        # loss_dict['occ']=-loss_occ*0.01
   
        return loss_dict

if __name__ == '__main__':
    head = VanillaPlanHead2(hidden_dim=512)
    input = torch.ones([4,512,180,180])
    x = head(input)
    print(x)
    # print(x.keys())
    # print(x["x1"].shape)
    # pred_dict={'x{}'.format(i):torch.rand(4,3,1)for i in range(1,7)}
    # gt_trajectory=[[torch.rand(4)]*3]*6
    # # gt_trajectory=torch.stack([torch.stack(gt_trajectory[i])for i in range(len(gt_trajectory))])
    # # print(gt_trajectory.shape)
    # # exit(0)
    # loss=head.loss(pred_dict,gt_trajectory)
    # print(loss)